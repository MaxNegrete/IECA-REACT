import ListaRecetas from "./components/ListaRecetas";

function App() {
  return (
    <div>
      <ListaRecetas />
    </div>
  );
}

export default App;